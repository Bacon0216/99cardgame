#ifndef CPU_H_INCLUDED
#define CPU_H_INCLUDED
#include <iostream>
#include <vector>
#include "player.h"
using namespace std;

class CPU:public Player
{

};

#endif