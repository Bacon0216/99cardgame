#ifndef SUIT_H_INCLUDED
#define SUIT_H_INCLUDED
#include <iostream>
#include <vector>

using namespace std;

class Suits
{
public:
    Suits();
    string suit;
};

#endif